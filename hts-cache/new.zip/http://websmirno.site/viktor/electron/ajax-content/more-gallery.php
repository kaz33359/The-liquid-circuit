<div class="col-6 col-md-4 show filter-all filter-electrica">
					<a href="images/gallery-img01.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery-img01.jpg" alt=""></a>
				</div>
				<div class="col-6 col-md-4 show filter-all filter-electrica">
					<a href="images/gallery-img02.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery-img02.jpg" alt=""></a>
				</div>
				<div class="col-6 col-md-4 show filter-all filter-heating">
					<a href="images/gallery-img03.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery-img03.jpg" alt=""></a>
				</div>
				<div class="col-6 col-md-4 show filter-all filter-heating">
					<a href="images/gallery-img04.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery-img04.jpg" alt=""></a>
				</div>
				<div class="col-6 col-md-4 show filter-all filter-conditioning">
					<a href="images/gallery-img05.jpg" class="tt-gallery"><div class="gallery__icon"></div><img src="images/gallery-img05.jpg" alt=""></a>
				</div>